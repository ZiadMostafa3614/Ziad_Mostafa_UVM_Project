#=============================================================================
# waivers.do — Coverage Exclusions for AXI4 Memory UVM Environment
#=============================================================================

# Exclude unreachable implicit FSM default arms
coverage exclude -srcfile axi4.v -linerange 120 -code b -allfalse
coverage exclude -srcfile axi4.v -linerange 185 -code b -allfalse

# Exclude integer j loop variable toggle coverage in axi_memory.v
coverage exclude -du axi4_memory -toggle {j}
