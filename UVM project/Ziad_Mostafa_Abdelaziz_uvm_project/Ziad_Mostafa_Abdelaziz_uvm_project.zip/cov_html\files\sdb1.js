var g_db_data = {"11":1,"9":1,"6":1,"8":1,"1":1,"7":1,"3":1,"5":1};
processScopesDbFile(g_db_data);