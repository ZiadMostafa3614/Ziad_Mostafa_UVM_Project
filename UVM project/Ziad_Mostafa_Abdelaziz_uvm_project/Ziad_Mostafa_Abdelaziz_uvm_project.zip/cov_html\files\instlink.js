var g_data = {"10":[9,"vif",1],"12":[11,"mem_inst",1],"13":[11,"checker_inst",1],"11":[9,"dut",1],"9":[-1,"top",1],"15":[-1,"axi_uvm_pkg",1]};
processInstLinks(g_data);