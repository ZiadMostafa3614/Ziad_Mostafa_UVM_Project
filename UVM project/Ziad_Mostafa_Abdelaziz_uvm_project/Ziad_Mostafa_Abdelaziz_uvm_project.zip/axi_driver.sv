//=============================================================================
// axi_driver.sv — Active UVM Bus Driver Class
//=============================================================================
`ifndef AXI_DRIVER_SV
`define AXI_DRIVER_SV

class axi_driver extends uvm_driver #(axi_seq_item);

    `uvm_component_utils(axi_driver)

    virtual axi4_if.DRIVER vif;

    function new(string name = "axi_driver", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    virtual function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db #(virtual axi4_if)::get(this, "", "vif", vif)) begin
            `uvm_fatal("DRV", "Virtual interface 'vif' not found in uvm_config_db")
        end
    endfunction

    virtual task run_phase(uvm_phase phase);
        reset_signals();
        wait (vif.ARESETn === 1'b1);
        @(vif.drv_cb);
        forever begin
            seq_item_port.get_next_item(req);
            drive_item(req);
            seq_item_port.item_done();
        end
    endtask

    virtual task reset_signals();
        vif.drv_cb.AWVALID <= 0; vif.drv_cb.AWADDR <= '0; vif.drv_cb.AWLEN <= '0; vif.drv_cb.AWSIZE <= '0;
        vif.drv_cb.WVALID  <= 0; vif.drv_cb.WDATA  <= '0; vif.drv_cb.WLAST <= 0;
        vif.drv_cb.BREADY  <= 0;
        vif.drv_cb.ARVALID <= 0; vif.drv_cb.ARADDR <= '0; vif.drv_cb.ARLEN <= '0; vif.drv_cb.ARSIZE <= '0;
        vif.drv_cb.RREADY  <= 0;
    endtask

    virtual task drive_item(axi_seq_item item);
        if (item.op == OP_WRITE) begin
            drive_write(item);
        end else begin
            drive_read(item);
        end
    endtask

    virtual task drive_write(axi_seq_item item);
        // Address Phase
        vif.drv_cb.AWADDR  <= item.addr;
        vif.drv_cb.AWLEN   <= item.len;
        vif.drv_cb.AWSIZE  <= item.size;
        vif.drv_cb.AWVALID <= 1'b1;

        // Drive Data Phase 1st beat
        vif.drv_cb.WDATA  <= item.wdata[0];
        vif.drv_cb.WVALID <= 1'b1;
        vif.drv_cb.WLAST  <= (item.len == 0);

        // Wait for AWREADY
        do @(vif.drv_cb); while (!vif.drv_cb.AWREADY);
        vif.drv_cb.AWVALID <= 1'b0;

        // Drive remaining beats if len > 0
        for (int b = 0; b <= int'(item.len); b++) begin
            if (b > 0) begin
                vif.drv_cb.WDATA  <= item.wdata[b];
                vif.drv_cb.WVALID <= 1'b1;
                vif.drv_cb.WLAST  <= (b == int'(item.len));
            end
            do @(vif.drv_cb); while (!vif.drv_cb.WREADY);
        end
        vif.drv_cb.WVALID <= 1'b0;
        vif.drv_cb.WLAST  <= 1'b0;

        // Response Phase
        vif.drv_cb.BREADY <= 1'b1;
        do @(vif.drv_cb); while (!vif.drv_cb.BVALID);
        item.resp = axi_resp_e'(vif.drv_cb.BRESP);
        @(vif.drv_cb);
        vif.drv_cb.BREADY <= 1'b0;
    endtask

    virtual task drive_read(axi_seq_item item);
        // Address Phase
        vif.drv_cb.ARADDR  <= item.addr;
        vif.drv_cb.ARLEN   <= item.len;
        vif.drv_cb.ARSIZE  <= item.size;
        vif.drv_cb.ARVALID <= 1'b1;
        do @(vif.drv_cb); while (!vif.drv_cb.ARREADY);
        vif.drv_cb.ARVALID <= 1'b0;

        // Data Phase
        item.rdata = new[item.len + 1];
        for (int b = 0; b <= int'(item.len); b++) begin
            vif.drv_cb.RREADY <= 1'b1;
            do @(vif.drv_cb); while (!vif.drv_cb.RVALID);
            item.rdata[b] = vif.drv_cb.RDATA;
            item.resp     = axi_resp_e'(vif.drv_cb.RRESP);
        end
        @(vif.drv_cb);
        vif.drv_cb.RREADY <= 1'b0;
    endtask

endclass : axi_driver

`endif
