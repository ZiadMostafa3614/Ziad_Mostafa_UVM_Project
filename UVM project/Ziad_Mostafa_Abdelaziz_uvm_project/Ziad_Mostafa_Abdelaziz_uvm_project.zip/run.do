if {[file exists work]} { vdel -lib work -all }
vlib work

# Compile RTL (Verilog)
vlog +cover=bcesft axi_memory.v axi4.v

# Compile UVM Package & Testbench
vlog -sv +cover=bcesft +incdir+. \
    +incdir+C:/questasim64_2021.1/verilog_src/uvm-1.1d/src \
    C:/questasim64_2021.1/verilog_src/uvm-1.1d/src/uvm_pkg.sv \
    axi4_if.sv \
    axi4_assertions.sv \
    axi_uvm_pkg.sv \
    top.sv

# Optimize with full coverage and visibility
vopt top -o top_opt +acc +cover=bcesft -suppress 3009

# 1. Run Main Random Test
vsim top_opt -coverage -assertdebug +UVM_TESTNAME=axi_random_test -suppress 3009 -sv_lib C:/questasim64_2021.1/uvm-1.1d/win64/uvm_dpi -onfinish stop
do waivers.do
run -all
coverage save cov_random.ucdb

# 2. Run Factory Override Delay Test (Commented out)
# vsim top_opt -coverage -assertdebug +UVM_TESTNAME=axi_delay_test -suppress 3009 -sv_lib C:/questasim64_2021.1/uvm-1.1d/win64/uvm_dpi -onfinish stop
# do waivers.do
# run -all
# coverage save cov_delay.ucdb

# 3. Run Optional Burst Test (Commented out)
# vsim top_opt -coverage -assertdebug +UVM_TESTNAME=axi_burst_test -suppress 3009 -sv_lib C:/questasim64_2021.1/uvm-1.1d/win64/uvm_dpi -onfinish stop
# do waivers.do
# run -all
# coverage save cov_burst.ucdb

# Generate Comprehensive Reports for Test 1
coverage report -codeAll -cvg -verbose -output coverage_report.txt cov_random.ucdb
vcover report -cvg -details -output cvg_details.txt cov_random.ucdb
coverage report -summary cov_random.ucdb
assertion report -file assertion_cov_report.txt -verbose
