//=============================================================================
// axi_sequences.sv — UVM Sequence Library for AXI Operations
//=============================================================================
`ifndef AXI_SEQUENCES_SV
`define AXI_SEQUENCES_SV

// Base Sequence
class axi_base_seq extends uvm_sequence #(axi_seq_item);
    `uvm_object_utils(axi_base_seq)

    function new(string name = "axi_base_seq");
        super.new(name);
    endfunction
endclass

// Single-Beat Write Sequence
class axi_single_write_seq extends axi_base_seq;
    `uvm_object_utils(axi_single_write_seq)

    function new(string name = "axi_single_write_seq");
        super.new(name);
    endfunction

    virtual task body();
        req = axi_seq_item::type_id::create("req");
        start_item(req);
        if (!req.randomize() with {
            op   == OP_WRITE;
            len  == 8'd0; // Single beat
            size == 3'b010;
        }) begin
            `uvm_fatal("SEQ", "Randomization failed for single write sequence")
        end
        finish_item(req);
    endtask
endclass

// Single-Beat Read Sequence
class axi_single_read_seq extends axi_base_seq;
    `uvm_object_utils(axi_single_read_seq)

    function new(string name = "axi_single_read_seq");
        super.new(name);
    endfunction

    virtual task body();
        req = axi_seq_item::type_id::create("req");
        start_item(req);
        if (!req.randomize() with {
            op   == OP_READ;
            len  == 8'd0; // Single beat
            size == 3'b010;
        }) begin
            `uvm_fatal("SEQ", "Randomization failed for single read sequence")
        end
        finish_item(req);
    endtask
endclass

// Directed Write Followed by Read to Same Address Sequence
class axi_write_read_seq extends axi_base_seq;
    `uvm_object_utils(axi_write_read_seq)

    rand bit [15:0] target_addr;
    rand bit [31:0] target_data;

    constraint c_target { target_addr[1:0] == 2'b00; target_addr < 16'h1000; }

    function new(string name = "axi_write_read_seq");
        super.new(name);
    endfunction

    virtual task body();
        // Step 1: Write
        req = axi_seq_item::type_id::create("req_wr");
        start_item(req);
        if (!req.randomize() with {
            op          == OP_WRITE;
            len         == 8'd0;
            size        == 3'b010;
            addr        == target_addr;
            wdata[0]    == target_data;
        }) begin
            `uvm_fatal("SEQ", "Randomization failed for write phase")
        end
        finish_item(req);

        // Step 2: Readback
        req = axi_seq_item::type_id::create("req_rd");
        start_item(req);
        if (!req.randomize() with {
            op   == OP_READ;
            len  == 8'd0;
            size == 3'b010;
            addr == target_addr;
        }) begin
            `uvm_fatal("SEQ", "Randomization failed for read phase")
        end
        finish_item(req);
    endtask
endclass

// Bulk Constrained Random Sequence (Multi-Beat & Single-Beat)
class axi_random_seq extends axi_base_seq;
    `uvm_object_utils(axi_random_seq)

    int num_txn = 180;

    function new(string name = "axi_random_seq");
        super.new(name);
    endfunction

    virtual task body();
        for (int i = 0; i < num_txn; i++) begin
            req = axi_seq_item::type_id::create($sformatf("req_%0d", i));
            start_item(req);
            if (!req.randomize() with {
                len dist { 8'd0 :/ 30, [8'd1:8'd3] :/ 30, [8'd4:8'd7] :/ 20, [8'd8:8'd15] :/ 20 };
            }) begin
                `uvm_fatal("SEQ", "Randomization failed in random sequence")
            end
            finish_item(req);
        end
    endtask
endclass

// Optional Burst Sequence (Verifying Burst Feature)
class axi_burst_seq extends axi_base_seq;
    `uvm_object_utils(axi_burst_seq)

    int num_txn = 30;

    function new(string name = "axi_burst_seq");
        super.new(name);
    endfunction

    virtual task body();
        for (int i = 0; i < num_txn; i++) begin
            req = axi_seq_item::type_id::create($sformatf("burst_req_%0d", i));
            start_item(req);
            if (!req.randomize() with {
                len inside {[1:15]}; // Multi-beat bursts
            }) begin
                `uvm_fatal("SEQ", "Randomization failed in burst sequence")
            end
            finish_item(req);
        end
    endtask
endclass

`endif
